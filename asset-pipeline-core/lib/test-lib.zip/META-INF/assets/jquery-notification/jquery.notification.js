//=require_tree .
console.log("Wooh Im JQuery Notofication!");
