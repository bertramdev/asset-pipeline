console.log("This should be required by gstringtest.js")
