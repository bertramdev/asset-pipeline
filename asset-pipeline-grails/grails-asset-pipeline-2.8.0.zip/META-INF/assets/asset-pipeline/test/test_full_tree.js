//=require_self
//=require_full_tree libs

console.log("Initial Testing Stack for dependency load order");
