package asset.pipeline.grails;


public enum UrlBase {
    SERVER_BASE_URL,
    CONTEXT_PATH,
    NONE
}
